﻿namespace PuntoVenta.Models
{
    public class ApiResult
    {
        public string message { get; set; }
        public List<Product> list { get; set; }
        public Product ObjProduct { get; set; }
    }
}
