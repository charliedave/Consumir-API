﻿namespace PuntoVenta.Models
{
    public class CredentialResult
    {
        public string token {  get; set; }

    }
}
