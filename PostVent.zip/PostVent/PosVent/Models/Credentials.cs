﻿namespace PuntoVenta.Models
{
    public class Credentials
    {
        public string user {  get; set; }
        public string password { get; set; }

    }
}
