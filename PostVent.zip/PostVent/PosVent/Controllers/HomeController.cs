using Microsoft.AspNetCore.Mvc;
using PuntoVenta.Models;
using System.Diagnostics;
using PuntoVenta.Services;
namespace PuntoVenta.Controllers
{
    public class HomeController : Controller
    {
        private readonly IServiceApi _serviceApi;

        public HomeController(IServiceApi serviceApi)
        {
            _serviceApi = serviceApi;
        }

        public async Task<IActionResult> Index()
        {
            List<Product> lstProduct= await _serviceApi.ListProduct();
            return View(lstProduct);
        }

        public async Task<IActionResult> Product(int idProduct)
        {

            Product modelProduct = new Product();

            ViewBag.Accion = "New Product";

            if (idProduct != 0)
            {

                ViewBag.Accion = "Edit Produc";
                modelProduct = await _serviceApi.Get(idProduct);
            }

            return View(modelProduct);
        }

        [HttpPost]
        public async Task<IActionResult> SaveChanges(Product objProduct)
        {

            bool result;

            if (objProduct.ProductId == 0)
            {
                result = await _serviceApi.Save(objProduct);
            }
            else
            {
                result = await _serviceApi.Edit(objProduct);
            }


            if (result)
                return RedirectToAction("Index");
            else
                return NoContent();

        }

        [HttpGet]
        public async Task<IActionResult> Delete(int ProductId)
        {

            var result = await _serviceApi.Delete(ProductId);

            if (result)
                return RedirectToAction("Index");
            else
                return NoContent();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}