﻿using PuntoVenta.Models;

namespace PuntoVenta.Services
{
    public interface IServiceApi
    {
        Task<List<Product>> ListProduct();
        Task<Product> Get(int ProductId);
        Task<bool> Save(Product ObjProduct);
        Task<bool> Edit(Product ObjProduct);

        Task<bool> Delete(int ProductId);

    }
}
