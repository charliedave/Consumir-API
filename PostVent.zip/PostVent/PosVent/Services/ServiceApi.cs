﻿using Newtonsoft.Json;
using PuntoVenta.Models;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace PuntoVenta.Services
{
    public class ServiceApi : IServiceApi
    {
        private static string _user;
        private static string _password;
        private static string _baseUrl;
        private static string _token;

        public ServiceApi()
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build();

            _user = builder.GetSection("ApiSettings:user").Value;
            _password = builder.GetSection("ApiSettings:password").Value;
            _baseUrl = builder.GetSection("ApiSettings:baseUrl").Value;


        }
        public async Task Authorization() 
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri(_baseUrl);

            var credentials = new Credentials() { user = _user, password = _password };
            var content = new StringContent(JsonConvert.SerializeObject(credentials), Encoding.UTF8, "application/json");
            var response = await client.PostAsync("api/Autenticacion/Validar", content);
            var jsonresponse = await response.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<CredentialResult>(jsonresponse);

            _token = result.token;
        }

        public async Task<List<Product>> ListProduct()
        {
            List<Product> lstProducts = new List<Product>();
            
            await Authorization();

            var client = new HttpClient();
            client.BaseAddress = new Uri(_baseUrl);
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _token);

            var response = await client.GetAsync("api/Autenticacion/ListaProduct");

            if (response.IsSuccessStatusCode)
            {
                var jsonresponse = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<ApiResult>(jsonresponse);
                lstProducts = result.list;
            }

            return lstProducts;
        }

        public async Task<Product> Get(int ProductId)
        {
            Product objProduct = new Product();

            await Authorization();


            var client = new HttpClient();
            client.BaseAddress = new Uri(_baseUrl);
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _token);
            var response = await client.GetAsync($"api/Producto/Obtener/{ProductId}");

            if (response.IsSuccessStatusCode)
            {

                var json_respuesta = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<ApiResult>(json_respuesta);
                objProduct = result.ObjProduct;
            }

            return objProduct;

        }

        public async Task<bool> Save(Product objProdcut)
        {
            bool result = false;

            await Authorization();

            var client = new HttpClient();
            client.BaseAddress = new Uri(_baseUrl);
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _token);

            var content = new StringContent(JsonConvert.SerializeObject(objProdcut), Encoding.UTF8, "application/json");

            var response = await client.PostAsync("api/Producto/Save/", content);

            if (response.IsSuccessStatusCode)
            {
                result = true;
            }

            return result;

        }

        public async Task<bool> Edit(Product objProdcut)
        {
            bool result = false;

            await Authorization();

            var client = new HttpClient();
            client.BaseAddress = new Uri(_baseUrl);
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _token);

            var content = new StringContent(JsonConvert.SerializeObject(objProdcut), Encoding.UTF8, "application/json");

            var response = await client.PutAsync("api/Producto/Edit/", content);

            if (response.IsSuccessStatusCode)
            {
                result = true;
            }

            return result;

        }

        public async Task<bool> Delete(int ProductId)
        {
            bool result = false;

            await Authorization();

            var client = new HttpClient();
            client.BaseAddress = new Uri(_baseUrl);
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _token);
          
            var response = await client.DeleteAsync($"api/Producto/Delete/{ProductId}");

            if (response.IsSuccessStatusCode)
            {
                result = true;
            }

            return result;
        }
    }
}
